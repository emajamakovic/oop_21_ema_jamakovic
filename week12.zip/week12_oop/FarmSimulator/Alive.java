
package farmsimulator;

public interface Alive {
    public void liveHour();
}
