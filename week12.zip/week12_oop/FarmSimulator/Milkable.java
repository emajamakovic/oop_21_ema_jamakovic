
package farmsimulator;


public interface Milkable {
    public double milk();
}
